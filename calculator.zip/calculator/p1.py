import tkinter as tk
import tkinter.messagebox

win = tk.Tk()
win.title('My Calculator')
win.configure(bg="#1A2030")  # Background color
win.resizable(False, False)

# Main frame
frame = tk.Frame(win, bg="#1A2030", padx=10, pady=10)
frame.pack()

# Entry widget (styled)
entry = tk.Entry(frame, borderwidth=0, width=25, font=("Segoe UI", 20), bg="#36455D", fg="white", insertbackground="white", justify="right")
entry.grid(row=0, column=0, columnspan=4, ipady=15, pady=5)

def click(num):
	entry.insert(tk.END, num)

def equal():
	try:
		res = str(eval(entry.get()))
		entry.delete(0, tk.END)
		entry.insert(0, res)
	except:
		tk.messagebox.showinfo("Error", "Syntax Error")

def clear():
	entry.delete(0, tk.END)

# Button layout (4 columns × 6 rows)
buttons = [
	('Flr', 1, 0), ('Ceil', 1, 1), ('C', 1, 2), ('<-', 1, 3),
	('%', 2, 0), ('x²', 2, 1), ('1/x', 2, 2), ('/', 2, 3),
	('7', 3, 0), ('8', 3, 1), ('9', 3, 2), ('*', 3, 3),
	('4', 4, 0), ('5', 4, 1), ('6', 4, 2), ('-', 4, 3),
	('1', 5, 0), ('2', 5, 1), ('3', 5, 2), ('+', 5, 3),
	('Clear', 6, 0), ('0', 6, 1), ('.', 6, 2), ('=', 6, 3),
]

# Custom button style
def create_button(text, row, col):
	color = "#2D2F36"  # Default button color
	fg = "white"
	if text == '=':
		color = "#4CC2FF"
		fg = "black"
	elif text in ('+', '-', '*', '/', 'C', 'Flr', 'Ceil', '<-', 'x²', '1/x', '%'):
		color = "#2D3245"

	btn = tk.Button(frame, text=text, bg=color, fg=fg, font=("Segoe UI", 14),
	                activebackground="#4CC2FF", activeforeground="black",
	                padx=20, pady=20, border=0, width=4,
	                command=lambda t=text: handle_click(t))
	btn.grid(row=row, column=col, padx=2, pady=2)

def handle_click(t):
	if t == "Clear":
		clear()
	elif t == "=":
		equal()
	elif t == "C":
		clear()
	elif t == "<-":
		entry.delete(len(entry.get())-1)
	elif t == "x²":
		try:
			val = float(entry.get())
			entry.delete(0, tk.END)
			entry.insert(0, str(val**2))
		except:
			entry.delete(0, tk.END)
	elif t == "1/x":
		try:
			val = float(entry.get())
			entry.delete(0, tk.END)
			entry.insert(0, str(1/val))
		except:
			entry.delete(0, tk.END)
	elif t == "Flr":
		try:
			import math
			val = float(entry.get())
			entry.delete(0, tk.END)
			entry.insert(0, str(math.floor(val)))
		except:
			entry.delete(0, tk.END)
	elif t == "Ceil":
		try:
			import math
			val = float(entry.get())
			entry.delete(0, tk.END)
			entry.insert(0, str(math.ceil(val)))
		except:
			entry.delete(0, tk.END)
	else:
		click(t)

# Create all buttons
for txt, r, c in buttons:
	create_button(txt, r, c)

win.mainloop()
